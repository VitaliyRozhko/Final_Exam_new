#!/usr/bin/bash

#create an intermediate list of emails
while IFS=, read -r col1 col2 col3 col4 col5 col6; do
	first=${col3:0:1}
        rest=$(echo $col3 | cut -d' ' -f2)
        col5_new=${first,}${rest,,}"@abc.com"
	echo "${col5_new}"
done < <(tail -n +2 $1) > list  

#find unique emails
while read -r; do
	printf '%s\n' "$REPLY"
done < list | sort | uniq -di > list1

#start of the main replacement algorithm
while IFS=, read -r col1 col2 col3 col4 col5 col6; do

#change to a capital letter in the first and last name
	first1=${col3%% *} 
        second1=$(echo $col3 | cut -d ' ' -f2)
        IFS=- read third1 third2 <<< "$second1" 	#divide a surname consisting of two
	first1=${first1^}; second1=${second1^}; third1=${third1^}; third2=${third2^} 
#combine changed names and surnames
        if [ -z "$third2" ];then
           col3=${first1}" "${second1}
         else col3=${first1}" "${third1}"-"${third2}
        fi

#fill in the email field
        first2=${col3:0:1}
        rest=$(echo $col3 | cut -d ' ' -f2)
        col5=${first2,}${rest,,}"@abc.com"
#find matching emails and add id to them
    while  IFS= read -r line; do
    if [[ "$line" == "$col5" ]]; then 
  	first2=${col3:0:1}
        rest=$(echo $col3 | cut -d ' ' -f2)
        col5=${first2,}${rest,,}${col2}@abc.com
	break
    fi
    done < list1

#fill the file with new column values
    echo "${col1},${col2},${col3},${col4},${col5},${col6},${col7}"

done < <(tail -n +2 $1) > accounts_new.csv 

#add a header from the source csv file to the csv file
head1=($(head -n 1 $1))
sed -i -e '1i'${head1[@]}'' accounts_new.csv

rm -r list list1 #remove intermediate files
