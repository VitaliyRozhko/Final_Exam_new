[string]$path=$args[0] #\accounts.csv
#convert csv format
$CSVdata = Get-Content -Path $path | ConvertFrom-Csv 
#change to a capital letter in the names and surnames
$CSVdata | ForEach-Object {
    $name, $surname = $_.name -Split ' '
    $name = $name.substring(0,1).toupper()+$name.substring(1).tolower()
    # additional check for double surnames
    if ($surname -like "*-*") {
        $surname1, $surname2 = $surname -Split '-'
        $surname1 = $surname1.substring(0,1).toupper()+$surname1.substring(1).tolower()
        $surname2 = $surname2.substring(0,1).toupper()+$surname2.substring(1).tolower()
        $_.name = $name + ' ' + $surname1 + '-' + $surname2
    }
    else {
        $surname = $surname.substring(0,1).toupper()+$surname.substring(1).tolower()
        $_.name = $name + ' ' + $surname
    }
}
#fill in the email field
$CSVdata | ForEach-Object {
    $First, $Rest = $_.name -Split ' '
    $First = $First.ToLower()
    $_.email = $First[0] + $Rest.ToLower() + '@abc.com'
    }
#choose unique names and surnames
$DupName = $CSVdata.email | Group-Object | Sort-Object Count | Where-Object { $_.Count -gt 1 } | Select-Object Name
#check for identical names and surnames and add ID to email
$DupName | ForEach-Object {
        $CSVdata | ForEach-Object {         
        $First, $Rest = $_.name -Split ' '
        $First = $First.ToLower()
        if ($DupName.name -eq $_.email) {
        $_.email = $First[0] + $Rest.ToLower() + $_.location_id + '@abc.com'
        }
    }
}

#convert to csv and save to current folder
$path_save = $path -replace "accounts.csv", "accounts_new.csv"
$CSVdata | ConvertTo-Csv | Set-Content -Path $path_save 